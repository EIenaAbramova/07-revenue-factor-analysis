$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot -Parent
$excelApp=New-Object -ComObject Excel.Application
$excelApp.Visible=$false
$excelApp.DisplayAlerts=$false
try {
  $book=$excelApp.Workbooks.Open((Join-Path $taskRoot 'outputs/07_Excel.xlsx'))
  $excelApp.CalculateFullRebuild()
  if($book.Worksheets.Item('Порции').Range('I20').Value2 -ne 5994){throw 'Native task1 mismatch'}
  $names=$book.Worksheets.Item('ФИО')
  $original=$names.Range('A2').Value2
  $names.Range('A2').Value2='  Иванов   Иван  Иванович '
  $excelApp.CalculateFullRebuild()
  if($names.Range('H2').Value2 -ne 'Иванов И.И.'){throw 'Native name normalization mismatch'}
  $names.Range('A2').Value2=$original
  $summary=$book.Worksheets.Item('Общий итог')
  if($summary.Range('G3').Value2 -ne 12578){throw 'Native task3 mismatch'}
  $list=$summary.ListObjects.Item('Portions')
  $added=$list.ListRows.Add()
  $added.Range.Cells.Item(1,2).Value2='Кафе3'
  $added.Range.Cells.Item(1,3).Value2=100
  $excelApp.CalculateFullRebuild()
  if($summary.Range('G3').Value2 -ne 12678){throw 'Native expansion mismatch'}
  $added.Delete()
  $excelApp.CalculateFullRebuild()
  if($summary.Range('G3').Value2 -ne 12578){throw 'Native restore mismatch'}
  foreach($item in @(@('Порции','A1:I21','native_excel1'),@('ФИО','A1:K21','native_excel2'),@('Общий итог','A1:N21','native_excel3'))){
    $sheet=$book.Worksheets.Item($item[0])
    $sheet.PageSetup.PrintArea=$item[1]
    $sheet.PageSetup.Orientation=2
    $sheet.PageSetup.Zoom=$false
    $sheet.PageSetup.FitToPagesWide=1
    $sheet.PageSetup.FitToPagesTall=1
    $sheet.ExportAsFixedFormat(0,(Join-Path $taskRoot ('qa/'+$item[2]+'.pdf')))
  }
  $book.Worksheets.Item('Порции').Activate()
  $book.Save()
  $book.Close($false)
  $book=$excelApp.Workbooks.Open((Join-Path $taskRoot 'outputs/07_Анализ.xlsx'))
  $excelApp.CalculateFullRebuild()
  $sheet=$book.Worksheets.Item('Итоги')
  if([Math]::Abs($sheet.Range('B10').Value2-592771.5) -gt 0.001){throw 'Native revenue mismatch'}
  if([Math]::Abs($sheet.Range('B15').Value2) -gt 0.001){throw 'Native factor reconciliation mismatch'}
  $sheet.Activate();$book.Save();$book.Close($false)
  @{native_excel='passed';table_expansion='passed';name_normalization='passed';revenue_reconciliation='passed'} | ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $taskRoot 'qa/native_validation.json')
  Write-Output 'Native Microsoft Excel calculations and table expansion verified.'
} finally {$excelApp.Quit();[void][Runtime.InteropServices.Marshal]::ReleaseComObject($excelApp)}
