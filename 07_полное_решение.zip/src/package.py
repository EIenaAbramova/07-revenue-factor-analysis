from pathlib import Path
import shutil,zipfile,json,re
ROOT=Path(__file__).resolve().parents[1]
pub=ROOT/'GitHub';pub.mkdir(exist_ok=True)
readme=(ROOT/'README.md').read_text(encoding='utf-8')
for prefix in ['outputs/','docs/','sql/']:readme=readme.replace(']('+prefix,'](')
readme=readme.replace('## Повторить расчёты','## Исходники и повторение расчётов\n\n[Скачать полный проект](07_полное_решение.zip): исходные задания, код, готовые книги, конспект и результаты проверок. Распакуйте архив: команды ниже выполняются из его корневой папки.\n\n## Повторить расчёты')
readme+='\n\n## Предпросмотр\n\n![Анализ выручки](preview.png)\n'
(pub/'README.md').write_text(readme,encoding='utf-8')
for sub in ['outputs','docs','sql']:
    for f in (ROOT/sub).iterdir():
        if f.suffix in ['.xlsx','.csv','.md','.docx','.sql']:shutil.copy2(f,pub/f.name)
shutil.copy2(ROOT/'qa/data_summary.png',pub/'preview.png')
checks={name:json.loads((ROOT/'qa'/name).read_text(encoding='utf-8-sig')) for name in ['verification.json','native_validation.json']}
(pub/'validation.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(pub/'07_полное_решение.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in [ROOT/'README.md',ROOT/'requirements.txt',ROOT/'.gitignore']:
        z.write(f,f.relative_to(ROOT).as_posix())
    for directory in ['data','src','outputs','docs','sql','qa']:
        for f in (ROOT/directory).iterdir():
            if f.is_file() and f.suffix in ['.xlsx','.csv','.md','.docx','.sql','.py','.mjs','.ps1','.json']:
                z.write(f,f.relative_to(ROOT).as_posix())
for link in re.findall(r'\]\(([^)]+)\)',readme):
    if not link.startswith(('https:','#')):assert (pub/link).exists(),link
with zipfile.ZipFile(pub/'07_полное_решение.zip') as z:
    assert z.testzip() is None
    assert 'src/analyze.py' in z.namelist() and 'data/data_source.xlsx' in z.namelist()
print(json.dumps([str(p.resolve()) for p in pub.iterdir() if p.is_file()],ensure_ascii=False,indent=2))
