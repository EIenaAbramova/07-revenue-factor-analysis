from pathlib import Path
import re
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1]
doc=Document()
sec=doc.sections[0]
sec.top_margin=sec.bottom_margin=Cm(1.8)
sec.left_margin=sec.right_margin=Cm(2)
sec.page_width=Cm(21);sec.page_height=Cm(29.7)
for name in ['Normal','Body Text','List Bullet']:
    style=doc.styles[name];style.font.name='Arial';style.font.size=Pt(10.5)
    style.paragraph_format.space_after=Pt(6)
    style.paragraph_format.line_spacing=1.1
for name,size in [('Title',22),('Heading 1',14),('Heading 2',12)]:
    st=doc.styles[name];st.font.name='Arial';st.font.size=Pt(size);st.font.color.rgb=RGBColor.from_string('543728')
doc.core_properties.title='07: подробный конспект решения'
doc.core_properties.author=''
code=False
for line in (ROOT/'docs/Конспект.md').read_text(encoding='utf-8').splitlines():
    if line.startswith('```'):code=not code;continue
    if not line.strip():continue
    if line.startswith('# '):doc.add_heading(line[2:],0);continue
    if line.startswith('## '):doc.add_heading(line[3:],1);continue
    p=doc.add_paragraph(style='List Bullet' if line.startswith('- ') else 'Normal')
    p.paragraph_format.keep_together=True
    if line.startswith('- '):line=line[2:]
    line=line.replace('**','').replace('`','')
    run=p.add_run(line)
    if code:
        run.font.name='Consolas';run.font.size=Pt(8)
        p.paragraph_format.space_after=Pt(1)
        p.paragraph_format.keep_with_next=True
        p.paragraph_format.line_spacing=1.0
        pr=p._p.get_or_add_pPr();shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'F3E9DE');pr.append(shade)
for element in list(doc.styles.element.iter(qn('w:pBdr'))):
    element.getparent().remove(element)
doc.save(ROOT/'docs/Конспект.docx')
print('DOCX saved')
